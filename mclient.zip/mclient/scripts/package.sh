#!/usr/bin/env bash
# Builds libmclient.so for arm64-v8a and packs dist/mclient.levipack
# (a zip with manifest.json + libmclient.so at its root).
set -euo pipefail

ROOT="$(cd "$(dirname "$0")/.." && pwd)"
ABI=arm64-v8a
BUILD="$ROOT/build/$ABI"
OUT="$ROOT/dist/$ABI/mclient"

NDK="${ANDROID_NDK_HOME:-${ANDROID_NDK_ROOT:-}}"
if [ -z "$NDK" ] || [ ! -f "$NDK/build/cmake/android.toolchain.cmake" ]; then
    echo "Set ANDROID_NDK_HOME to an Android NDK (r28c recommended)." >&2
    exit 1
fi
if [ ! -f "$ROOT/third_party/imgui/imgui.cpp" ]; then
    git clone --depth 1 --branch v1.91.9b https://github.com/ocornut/imgui "$ROOT/third_party/imgui"
fi

cmake -S "$ROOT" -B "$BUILD" -G Ninja \
    -DCMAKE_TOOLCHAIN_FILE="$NDK/build/cmake/android.toolchain.cmake" \
    -DANDROID_ABI=$ABI -DANDROID_PLATFORM=android-28 \
    -DANDROID_STL=c++_shared -DCMAKE_BUILD_TYPE=Release
cmake --build "$BUILD"

LIB="$BUILD/out/$ABI/libmclient.so"
[ -f "$LIB" ] || { echo "libmclient.so was not built" >&2; exit 1; }

rm -rf "$OUT"; mkdir -p "$OUT"
cp "$ROOT/manifest.json" "$OUT/"
cp "$LIB" "$OUT/"

PACK="$ROOT/dist/$ABI/mclient.levipack"
rm -f "$PACK"
if command -v zip >/dev/null; then
    (cd "$OUT" && zip -X -9 -q "$PACK" manifest.json libmclient.so)
else
    (cd "$OUT" && python3 -m zipfile -c "$PACK" manifest.json libmclient.so)
fi
echo "Created: $PACK"
