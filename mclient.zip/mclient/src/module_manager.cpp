#include "module_manager.h"

#include <algorithm>
#include <fstream>
#include <nlohmann/json.hpp>

#include "hud.h"
#include "modules/clock.h"
#include "modules/cps.h"
#include "modules/crosshair.h"
#include "modules/fps.h"
#include "modules/themes.h"

using json = nlohmann::json;

ModuleManager& ModuleManager::get() {
    static ModuleManager inst;
    return inst;
}

void ModuleManager::registerAll() {
    if (!mods_.empty()) return;
    // Add new modules here.
    mods_.push_back(std::make_unique<CpsModule>());
    mods_.push_back(std::make_unique<ClockModule>());
    mods_.push_back(std::make_unique<FpsModule>());
    mods_.push_back(std::make_unique<CrosshairModule>());
    mods_.push_back(std::make_unique<ThemesModule>());
}

void ModuleManager::renderAll(ImDrawList* dl, ImVec2 screen) {
    hud::beginFrame();
    for (auto& m : mods_)
        if (m->enabled) m->onRender(dl, screen);
}

Module* ModuleManager::find(const std::string& name) {
    for (auto& m : mods_) if (m->name == name) return m.get();
    return nullptr;
}

void ModuleManager::save(const std::filesystem::path& file) const {
    try {
        json root = json::object();
        for (const auto& m : mods_) {
            json jm;
            jm["enabled"] = m->enabled;
            json js = json::object();
            for (const Setting& s : m->settings) {
                switch (s.type) {
                    case Setting::Type::Slider: js[s.name] = s.value; break;
                    case Setting::Type::Toggle: js[s.name] = s.on; break;
                    case Setting::Type::Choice: js[s.name] = s.choice; break;
                    case Setting::Type::Color:  js[s.name] = {s.color[0], s.color[1], s.color[2], s.color[3]}; break;
                }
            }
            jm["settings"] = js;
            root[m->name] = jm;
        }
        std::error_code ec;
        std::filesystem::create_directories(file.parent_path(), ec);
        std::ofstream(file) << root.dump(2);
    } catch (...) {
        // Saving is best effort.
    }
}

void ModuleManager::load(const std::filesystem::path& file) {
    try {
        std::ifstream in(file);
        if (!in) return;
        const json root = json::parse(in);
        for (auto& m : mods_) {
            if (!root.contains(m->name)) continue;
            const json& jm = root[m->name];
            if (jm.contains("enabled") && jm["enabled"].is_boolean()) m->enabled = jm["enabled"];
            if (!jm.contains("settings")) continue;
            const json& js = jm["settings"];
            for (Setting& s : m->settings) {
                if (!js.contains(s.name)) continue;
                const json& v = js[s.name];
                switch (s.type) {
                    case Setting::Type::Slider:
                        if (v.is_number()) s.value = std::clamp(v.get<float>(), s.min, s.max);
                        break;
                    case Setting::Type::Toggle:
                        if (v.is_boolean()) s.on = v;
                        break;
                    case Setting::Type::Choice:
                        if (v.is_number_integer())
                            s.choice = std::clamp(v.get<int>(), 0, (int)s.choices.size() - 1);
                        break;
                    case Setting::Type::Color:
                        if (v.is_array() && v.size() == 4)
                            for (int i = 0; i < 4; ++i) s.color[i] = v[i].get<float>();
                        break;
                }
            }
        }
    } catch (...) {
        // A broken file just means defaults are used.
    }
}
