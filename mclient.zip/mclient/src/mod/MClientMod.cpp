#include "mod/MClientMod.h"

#include <dlfcn.h>

#include <algorithm>
#include <chrono>
#include <thread>

#include "gui/clickgui.h"
#include "imgui.h"
#include "imgui_impl_opengl3.h"
#include "input.h"
#include "module_manager.h"
#include <pl/Input.hpp>
#include <pl/memory/Hook.hpp>

namespace mclient {
namespace {

using SwapFn = EGLBoolean (*)(EGLDisplay, EGLSurface);
SwapFn gOrigSwap = nullptr;

EGLBoolean hookedSwap(EGLDisplay display, EGLSurface surface) {
    // Never let an exception escape into the game's render thread.
    try {
        MClientMod::instance().onFrame(display, surface);
    } catch (...) {
    }
    return gOrigSwap ? gOrigSwap(display, surface) : EGL_FALSE;
}

std::filesystem::path settingsFile(ll::mod::NativeMod& self) {
    return self.getConfigDir() / "settings.json";
}

}  // namespace

MClientMod::MClientMod() : mSelf(*ll::mod::NativeMod::current()) {}

MClientMod& MClientMod::instance() {
    static MClientMod inst;
    return inst;
}

bool MClientMod::load() {
    auto& mgr = ModuleManager::get();
    mgr.registerAll();
    mgr.load(settingsFile(mSelf));
    input::install();
    mSelf.getLogger().info("My client loaded");
    return true;
}

// eglSwapBuffers lives in libEGL, which may not be loaded yet when the mod is
// enabled, so a short-lived watcher thread retries until it can be hooked.
bool MClientMod::installHook() {
    if (mHooked.load()) return true;
    void* target = dlsym(RTLD_DEFAULT, "eglSwapBuffers");
    if (!target) return false;

    const int rc = pl::memory::hook(target, reinterpret_cast<void*>(&hookedSwap),
                                    reinterpret_cast<void**>(&gOrigSwap));
    if (rc != 0) return false;
    mHooked.store(true);
    mSelf.getLogger().info("Render hook installed");
    return true;
}

bool MClientMod::enable() {
    mEnabled.store(true);
    mStopWatcher.store(false);
    if (installHook()) return true;

    std::thread([this] {
        for (int i = 0; i < 240 && !mStopWatcher.load(); ++i) {   // up to ~2 minutes
            if (installHook()) return;
            std::this_thread::sleep_for(std::chrono::milliseconds(500));
        }
        if (!mHooked.load()) mSelf.getLogger().error("Could not find eglSwapBuffers");
    }).detach();
    return true;
}

bool MClientMod::disable() {
    mEnabled.store(false);
    mStopWatcher.store(true);
    ModuleManager::get().save(settingsFile(mSelf));
    // The detour stays installed but does nothing while disabled: unhooking a
    // function that another thread may be executing right now is not safe.
    return true;
}

bool MClientMod::unload() {
    ModuleManager::get().save(settingsFile(mSelf));
    return true;
}

void MClientMod::onFrame(EGLDisplay display, EGLSurface surface) {
    if (!mEnabled.load()) return;

    // Only draw on the game's main context (the swap can be called for other surfaces).
    EGLContext ctx = eglGetCurrentContext();
    if (ctx == EGL_NO_CONTEXT) return;

    EGLint w = 0, h = 0;
    eglQuerySurface(display, surface, EGL_WIDTH, &w);
    eglQuerySurface(display, surface, EGL_HEIGHT, &h);
    if (w < 64 || h < 64) return;                // ignore tiny helper surfaces

    if (mImGuiReady && ctx != mContext) {
        if (mContext != EGL_NO_CONTEXT) {
            // The context was recreated (app went to background and came back).
            ImGui_ImplOpenGL3_Shutdown();
            ImGui_ImplOpenGL3_Init("#version 300 es");
            mContext = ctx;
        } else {
            return;
        }
    }

    if (!mImGuiReady) {
        IMGUI_CHECKVERSION();
        ImGui::CreateContext();
        ImGuiIO& io = ImGui::GetIO();
        io.IniFilename = nullptr;
        ImGui::StyleColorsDark();

        // Scale the whole UI for the phone's screen size.
        const float ui = std::clamp(std::min(w, h) / 450.f, 1.5f, 3.5f);
        ImGui::GetStyle().ScaleAllSizes(ui);
        io.FontGlobalScale = ui;

        ImGui_ImplOpenGL3_Init("#version 300 es");
        mContext = ctx;
        mImGuiReady = true;
    }

    ImGuiIO& io = ImGui::GetIO();
    io.DisplaySize = ImVec2((float)w, (float)h);
    io.DeltaTime = 1.f / 60.f;
    {
        static auto last = std::chrono::steady_clock::now();
        const auto now = std::chrono::steady_clock::now();
        const float dt = std::chrono::duration<float>(now - last).count();
        last = now;
        if (dt > 0.f && dt < 1.f) io.DeltaTime = dt;
    }

    input::pump(io);
    ImGui_ImplOpenGL3_NewFrame();
    ImGui::NewFrame();

    const ImVec2 screen((float)w, (float)h);
    ModuleManager::get().renderAll(ImGui::GetBackgroundDrawList(), screen);
    ClickGUI::draw(screen);

    // Tell the input thread where the GUI is, so taps elsewhere go to the game.
    input::publish(ClickGUI::rects(),
                   ImGui::IsPopupOpen("", ImGuiPopupFlags_AnyPopupId | ImGuiPopupFlags_AnyPopupLevel),
                   io.WantTextInput);

    if (io.WantTextInput != mWantedText) {
        mWantedText = io.WantTextInput;
        if (mWantedText) pl::input::showKeyboard(); else pl::input::hideKeyboard();
    }

    // Save settings when the menu is closed.
    if (mWasVisible && !ClickGUI::visible) ModuleManager::get().save(settingsFile(mSelf));
    mWasVisible = ClickGUI::visible;

    ImGui::Render();
    ImGui_ImplOpenGL3_RenderDrawData(ImGui::GetDrawData());
}

}  // namespace mclient
