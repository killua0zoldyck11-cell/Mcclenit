#pragma once
#include <atomic>
#include <EGL/egl.h>
#include <pl/Mod.hpp>

namespace mclient {

// Lifecycle order used by LeviLaunchroid: load -> enable -> disable -> unload.
// Each returns false on failure.
class MClientMod {
public:
    static MClientMod& instance();

    bool load();
    bool enable();
    bool disable();
    bool unload();

    // Runs on the render thread, once per frame, just before the buffer swap.
    void onFrame(EGLDisplay display, EGLSurface surface);

private:
    MClientMod();

    bool installHook();

    ll::mod::NativeMod& mSelf;
    std::atomic<bool> mEnabled{false};
    std::atomic<bool> mHooked{false};
    std::atomic<bool> mStopWatcher{false};

    bool mImGuiReady = false;
    EGLContext mContext = EGL_NO_CONTEXT;
    bool mWantedText = false;
    bool mWasVisible = false;
};

}  // namespace mclient
