#pragma once
#include <string>
#include <vector>
#include <utility>
#include "imgui.h"

enum class Category { Movement, HUD, Render, Utility };

inline const char* categoryName(Category c) {
    switch (c) {
        case Category::Movement: return "Movement";
        case Category::HUD:      return "HUD";
        case Category::Render:   return "Render";
        case Category::Utility:  return "Utility";
    }
    return "";
}

// One configurable value shown in the module's expanded panel.
struct Setting {
    enum class Type { Slider, Toggle, Choice, Color };

    Type type;
    std::string name;
    float value = 0, min = 0, max = 1;     // Slider
    bool on = false;                       // Toggle
    int choice = 0;                        // Choice
    std::vector<std::string> choices;      // Choice
    float color[4] = {1, 1, 1, 1};         // Color

    static Setting slider(std::string n, float v, float lo, float hi) {
        Setting s; s.type = Type::Slider; s.name = std::move(n);
        s.value = v; s.min = lo; s.max = hi; return s;
    }
    static Setting toggle(std::string n, bool v) {
        Setting s; s.type = Type::Toggle; s.name = std::move(n); s.on = v; return s;
    }
    static Setting select(std::string n, std::vector<std::string> opts, int idx = 0) {
        Setting s; s.type = Type::Choice; s.name = std::move(n);
        s.choices = std::move(opts); s.choice = idx; return s;
    }
    static Setting colorPick(std::string n, float r, float g, float b, float a = 1.f) {
        Setting s; s.type = Type::Color; s.name = std::move(n);
        s.color[0] = r; s.color[1] = g; s.color[2] = b; s.color[3] = a; return s;
    }
};

class Module {
public:
    Module(std::string name, std::string desc, Category cat, bool enabled = false)
        : name(std::move(name)), description(std::move(desc)), category(cat), enabled(enabled) {}
    virtual ~Module() = default;

    // Called once per frame (inside the ImGui frame) when the module is on.
    virtual void onRender(ImDrawList* dl, ImVec2 screen) { (void)dl; (void)screen; }
    virtual void onEnable() {}
    virtual void onDisable() {}

    void setEnabled(bool v) {
        if (v == enabled) return;
        enabled = v;
        v ? onEnable() : onDisable();
    }

    Setting* find(const std::string& n) {
        for (auto& s : settings) if (s.name == n) return &s;
        return nullptr;
    }

    std::string name, description;
    Category category;
    bool enabled;
    std::vector<Setting> settings;
};
