#pragma once
#include <vector>
#include "imgui.h"

// Bridges LeviLaunchroid's touch/key callbacks (UI thread) to ImGui (render thread).
namespace input {

struct Rect { float x0, y0, x1, y1; };

void install();                               // register callbacks (once)
void pump(ImGuiIO& io);                       // render thread: feed queued events to ImGui
void publish(std::vector<Rect> rects, bool anyPopup, bool wantText);  // render thread, once per frame
int  tapsPerSecond();                         // taps that went to the game, last second

}  // namespace input
