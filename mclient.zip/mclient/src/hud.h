#pragma once
#include <cfloat>
#include "imgui.h"

// Stacks HUD boxes (FPS, Clock, CPS...) from the top-left corner so they never overlap.
namespace hud {

inline float& cursorY() { static float y = 0; return y; }

inline void beginFrame() { cursorY() = ImGui::GetFontSize() * 0.6f; }

inline void box(ImDrawList* dl, const char* text, float scale) {
    const float margin = ImGui::GetFontSize() * 0.6f;
    const float pad = ImGui::GetFontSize() * 0.35f;
    ImFont* f = ImGui::GetFont();
    const float size = ImGui::GetFontSize() * scale;
    const ImVec2 ts = f->CalcTextSizeA(size, FLT_MAX, 0.f, text);

    const ImVec2 p(margin, cursorY());
    const ImVec2 q(p.x + ts.x + pad * 2, p.y + ts.y + pad * 2);
    dl->AddRectFilled(p, q, IM_COL32(16, 16, 16, 190), pad);
    dl->AddText(f, size, ImVec2(p.x + pad, p.y + pad), IM_COL32_WHITE, text);
    cursorY() = q.y + margin * 0.5f;
}

}  // namespace hud
