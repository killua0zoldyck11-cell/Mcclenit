#include "input.h"

#include <atomic>
#include <cfloat>
#include <chrono>
#include <deque>
#include <mutex>
#include <string>
#include <unordered_map>

#include <pl/Input.hpp>

namespace input {
namespace {

using Clock = std::chrono::steady_clock;

struct Ev {
    enum class T { Pos, Button, Key, Text } t;
    float x = 0, y = 0;
    bool down = false;
    ImGuiKey key = ImGuiKey_None;
    std::string text;

    Ev(T type, float px = 0, float py = 0, bool d = false) : t(type), x(px), y(py), down(d) {}
};

// Android MotionEvent actions (masked).
constexpr int kDown = 0, kUp = 1, kMove = 2, kCancel = 3, kPtrDown = 5, kPtrUp = 6;
// Android key codes.
constexpr int kKeyEnter = 66, kKeyDel = 67;

std::mutex gMu;
std::vector<Ev> gQueue;
std::vector<Rect> gRects;
std::atomic<bool> gAnyPopup{false};
std::atomic<bool> gWantText{false};
std::deque<Clock::time_point> gTaps;
std::unordered_map<int, bool> gCaptured;   // pointerId -> goes to ImGui
int gMousePointer = -1;                    // pointer that drives the ImGui mouse
bool gInstalled = false;

bool insideGui(float x, float y) {
    if (gAnyPopup.load()) return true;
    for (const Rect& r : gRects)
        if (x >= r.x0 && x <= r.x1 && y >= r.y0 && y <= r.y1) return true;
    return false;
}

void push(Ev e) { gQueue.push_back(std::move(e)); }

bool onTouch(const pl::input::TouchEvent& e) {
    const int a = e.action & 0xff;
    const bool isDown = (a == kDown || a == kPtrDown);
    const bool isUp = (a == kUp || a == kPtrUp || a == kCancel);

    std::lock_guard<std::mutex> lk(gMu);

    if (isDown) {
        const bool cap = insideGui(e.x, e.y);
        gCaptured[e.pointerId] = cap;
        if (!cap) {
            const auto now = Clock::now();
            gTaps.push_back(now);
            while (!gTaps.empty() && now - gTaps.front() > std::chrono::seconds(1)) gTaps.pop_front();
            return false;
        }
        if (gMousePointer < 0) {
            gMousePointer = e.pointerId;
            push({Ev::T::Pos, e.x, e.y});
            push({Ev::T::Button, 0, 0, true});
        }
        return true;
    }

    auto it = gCaptured.find(e.pointerId);
    const bool cap = (it != gCaptured.end() && it->second);

    if (cap && e.pointerId == gMousePointer) {
        if (isUp) {
            push({Ev::T::Pos, e.x, e.y});
            push({Ev::T::Button, 0, 0, false});
            push({Ev::T::Pos, -FLT_MAX, -FLT_MAX});   // clear hover after the finger leaves
            gMousePointer = -1;
        } else {
            push({Ev::T::Pos, e.x, e.y});
        }
    }
    if (isUp && it != gCaptured.end()) gCaptured.erase(it);
    return cap;
}

bool onKey(const pl::input::KeyEvent& e) {
    if (!gWantText.load()) return false;
    std::lock_guard<std::mutex> lk(gMu);
    if (e.keyCode == kKeyDel) {
        Ev v{Ev::T::Key}; v.key = ImGuiKey_Backspace; v.down = e.isKeyDown; push(v);
    } else if (e.keyCode == kKeyEnter) {
        Ev v{Ev::T::Key}; v.key = ImGuiKey_Enter; v.down = e.isKeyDown; push(v);
    } else if (e.isKeyDown && e.unicodeChar >= 32) {
        Ev v{Ev::T::Text};
        unsigned int c = e.unicodeChar;           // encode as UTF-8
        if (c < 0x80) v.text += (char)c;
        else if (c < 0x800) { v.text += (char)(0xC0 | (c >> 6)); v.text += (char)(0x80 | (c & 0x3F)); }
        else { v.text += (char)(0xE0 | (c >> 12)); v.text += (char)(0x80 | ((c >> 6) & 0x3F)); v.text += (char)(0x80 | (c & 0x3F)); }
        push(v);
    }
    return true;
}

bool onText(const pl::input::TextInputEvent& e) {
    if (!gWantText.load()) return false;
    std::lock_guard<std::mutex> lk(gMu);
    Ev v{Ev::T::Text}; v.text = e.text; push(v);
    return true;
}

}  // namespace

void install() {
    if (gInstalled) return;
    gInstalled = true;
    pl::input::registerTouchCallback(onTouch);
    pl::input::registerKeyCallback(onKey);
    pl::input::registerTextInputCallback(onText);
}

void pump(ImGuiIO& io) {
    std::vector<Ev> q;
    {
        std::lock_guard<std::mutex> lk(gMu);
        q.swap(gQueue);
    }
    for (const Ev& e : q) {
        switch (e.t) {
            case Ev::T::Pos:    io.AddMousePosEvent(e.x, e.y); break;
            case Ev::T::Button: io.AddMouseButtonEvent(0, e.down); break;
            case Ev::T::Key:    io.AddKeyEvent(e.key, e.down); break;
            case Ev::T::Text:   io.AddInputCharactersUTF8(e.text.c_str()); break;
        }
    }
}

void publish(std::vector<Rect> rects, bool anyPopup, bool wantText) {
    {
        std::lock_guard<std::mutex> lk(gMu);
        gRects = std::move(rects);
    }
    gAnyPopup.store(anyPopup);
    gWantText.store(wantText);
}

int tapsPerSecond() {
    std::lock_guard<std::mutex> lk(gMu);
    const auto now = Clock::now();
    while (!gTaps.empty() && now - gTaps.front() > std::chrono::seconds(1)) gTaps.pop_front();
    return (int)gTaps.size();
}

}  // namespace input
