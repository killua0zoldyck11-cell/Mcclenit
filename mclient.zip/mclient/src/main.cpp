#include "mod/MClientMod.h"

#include <pl/Mod.hpp>

// Registers the mod with LeviLaunchroid. Used exactly once.
PL_REGISTER_MOD(mclient::MClientMod, mclient::MClientMod::instance());
