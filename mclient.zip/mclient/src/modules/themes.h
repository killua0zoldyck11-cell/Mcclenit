#pragma once
#include "gui/clickgui.h"
#include "module.h"

// Changes the menu accent color and corner radius.
class ThemesModule : public Module {
public:
    ThemesModule() : Module("Themes", "Change the menu colors and corners", Category::Utility, true) {
        settings.push_back(Setting::select("Theme", {"Default", "Ocean", "Sunset", "Forest", "Berry", "Custom"}, 0));
        settings.push_back(Setting::colorPick("Accent color", 0.216f, 0.541f, 0.867f));
        settings.push_back(Setting::slider("Corner radius", 8, 0, 16));
    }

    void onRender(ImDrawList*, ImVec2) override {
        static const ImVec4 presets[] = {
            {0.216f, 0.541f, 0.867f, 1.f},   // Default
            {0.122f, 0.557f, 0.639f, 1.f},   // Ocean
            {0.878f, 0.439f, 0.227f, 1.f},   // Sunset
            {0.231f, 0.561f, 0.302f, 1.f},   // Forest
            {0.706f, 0.263f, 0.478f, 1.f},   // Berry
        };
        const int t = find("Theme")->choice;
        if (t < 5) {
            ClickGUI::accent = presets[t];
        } else {
            const float* c = find("Accent color")->color;
            ClickGUI::accent = ImVec4(c[0], c[1], c[2], 1.f);
        }
        ClickGUI::radius = find("Corner radius")->value;
    }

    void onDisable() override { ClickGUI::resetTheme(); }
};
