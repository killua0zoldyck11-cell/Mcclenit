#pragma once
#include <cstdio>
#include <ctime>
#include "hud.h"
#include "module.h"

// Shows the device time.
class ClockModule : public Module {
public:
    ClockModule() : Module("Clock", "Shows the time", Category::HUD, true) {
        settings.push_back(Setting::select("Format", {"12h", "24h"}, 0));
        settings.push_back(Setting::slider("Scale", 100, 50, 200));
    }

    void onRender(ImDrawList* dl, ImVec2) override {
        std::time_t t = std::time(nullptr);
        std::tm tmv{};
        localtime_r(&t, &tmv);

        char buf[32];
        std::strftime(buf, sizeof buf, find("Format")->choice == 1 ? "%H:%M" : "%I:%M %p", &tmv);
        hud::box(dl, buf, find("Scale")->value / 100.f);
    }
};
