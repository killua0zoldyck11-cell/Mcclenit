#pragma once
#include <cstdio>
#include "hud.h"
#include "input.h"
#include "module.h"

// Counts screen taps that go to the game (taps on the menu are not counted).
class CpsModule : public Module {
public:
    CpsModule() : Module("CPS", "Shows taps per second", Category::HUD) {
        settings.push_back(Setting::slider("Scale", 100, 50, 200));
        settings.push_back(Setting::toggle("Show label", true));
    }

    void onRender(ImDrawList* dl, ImVec2) override {
        char buf[32];
        std::snprintf(buf, sizeof buf, find("Show label")->on ? "%d CPS" : "%d", input::tapsPerSecond());
        hud::box(dl, buf, find("Scale")->value / 100.f);
    }
};
