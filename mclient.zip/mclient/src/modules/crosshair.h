#pragma once
#include "module.h"

class CrosshairModule : public Module {
public:
    CrosshairModule() : Module("Custom crosshair", "Choose the shape, size and color", Category::Render) {
        settings.push_back(Setting::select("Style", {"Cross", "Dot", "Circle", "Square"}, 0));
        settings.push_back(Setting::slider("Size", 12, 4, 30));
        settings.push_back(Setting::slider("Thickness", 2, 1, 6));
        settings.push_back(Setting::slider("Gap", 4, 0, 12));
        settings.push_back(Setting::colorPick("Color", 1, 1, 1));
        settings.push_back(Setting::toggle("Outline", true));
    }

    void onRender(ImDrawList* dl, ImVec2 screen) override {
        const ImVec2 c(screen.x * 0.5f, screen.y * 0.5f);
        const int   style = find("Style")->choice;
        const float s = find("Size")->value;
        const float t = find("Thickness")->value;
        const float g = find("Gap")->value;
        const bool  outline = find("Outline")->on;
        const float* k = find("Color")->color;
        const ImU32 col = ImGui::ColorConvertFloat4ToU32(ImVec4(k[0], k[1], k[2], k[3]));
        const ImU32 black = IM_COL32(0, 0, 0, 255);

        auto arms = [&](float pad, ImU32 color) {
            dl->AddRectFilled(ImVec2(c.x - t / 2 - pad, c.y - g - s - pad), ImVec2(c.x + t / 2 + pad, c.y - g + pad), color);
            dl->AddRectFilled(ImVec2(c.x - t / 2 - pad, c.y + g - pad),     ImVec2(c.x + t / 2 + pad, c.y + g + s + pad), color);
            dl->AddRectFilled(ImVec2(c.x - g - s - pad, c.y - t / 2 - pad), ImVec2(c.x - g + pad, c.y + t / 2 + pad), color);
            dl->AddRectFilled(ImVec2(c.x + g - pad, c.y - t / 2 - pad),     ImVec2(c.x + g + s + pad, c.y + t / 2 + pad), color);
        };

        switch (style) {
            case 0:
                if (outline) arms(1.f, black);
                arms(0.f, col);
                break;
            case 1: {
                float r = s / 4 > 2 ? s / 4 : 2;
                if (outline) dl->AddCircleFilled(c, r + 1, black);
                dl->AddCircleFilled(c, r, col);
                break;
            }
            case 2:
                if (outline) dl->AddCircle(c, s, black, 0, t + 2);
                dl->AddCircle(c, s, col, 0, t);
                break;
            default:
                if (outline) dl->AddRect(ImVec2(c.x - s, c.y - s), ImVec2(c.x + s, c.y + s), black, 0, 0, t + 2);
                dl->AddRect(ImVec2(c.x - s, c.y - s), ImVec2(c.x + s, c.y + s), col, 0, 0, t);
                break;
        }
    }
};
