#pragma once
#include <cstdio>
#include "hud.h"
#include "module.h"

class FpsModule : public Module {
public:
    FpsModule() : Module("FPS", "Shows frames per second", Category::HUD, true) {
        settings.push_back(Setting::slider("Scale", 100, 50, 200));
        settings.push_back(Setting::toggle("Show label", true));
    }

    void onRender(ImDrawList* dl, ImVec2) override {
        char buf[32];
        std::snprintf(buf, sizeof buf, find("Show label")->on ? "%d FPS" : "%d", (int)ImGui::GetIO().Framerate);
        hud::box(dl, buf, find("Scale")->value / 100.f);
    }
};
