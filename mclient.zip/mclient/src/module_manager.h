#pragma once
#include <filesystem>
#include <memory>
#include <vector>
#include "module.h"

class ModuleManager {
public:
    static ModuleManager& get();

    void registerAll();                       // creates every module
    void renderAll(ImDrawList* dl, ImVec2 screen);

    // Settings are stored as JSON in the mod's config folder.
    void load(const std::filesystem::path& file);
    void save(const std::filesystem::path& file) const;

    std::vector<std::unique_ptr<Module>>& modules() { return mods_; }
    Module* find(const std::string& name);

private:
    std::vector<std::unique_ptr<Module>> mods_;
};
