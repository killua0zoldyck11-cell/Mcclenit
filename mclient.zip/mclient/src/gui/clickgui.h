#pragma once
#include <vector>
#include "imgui.h"
#include "input.h"

namespace ClickGUI {

extern bool visible;
extern ImVec4 accent;     // set by the Themes module
extern float radius;      // corner radius before UI scaling

void resetTheme();
void draw(ImVec2 screen);                    // call inside an ImGui frame
const std::vector<input::Rect>& rects();     // screen areas the GUI covers this frame

}  // namespace ClickGUI
