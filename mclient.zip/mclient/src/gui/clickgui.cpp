#include "gui/clickgui.h"
#include "module_manager.h"
#include <algorithm>
#include <cctype>
#include <string>

namespace ClickGUI {

bool visible = false;
ImVec4 accent(0.216f, 0.541f, 0.867f, 1.f);   // #378add
float radius = 8.f;

void resetTheme() {
    accent = ImVec4(0.216f, 0.541f, 0.867f, 1.f);
    radius = 8.f;
}

namespace {

std::vector<input::Rect> g_rects;
int  g_cat = -1;                                      // -1 = All
int  g_open = -1;                                     // expanded module index
char g_query[64] = "";

bool containsNoCase(const std::string& hay, const char* needle) {
    if (!*needle) return true;
    std::string h = hay, n = needle;
    std::transform(h.begin(), h.end(), h.begin(), ::tolower);
    std::transform(n.begin(), n.end(), n.begin(), ::tolower);
    return h.find(n) != std::string::npos;
}

void addRect() {
    const ImVec2 p = ImGui::GetWindowPos(), s = ImGui::GetWindowSize();
    g_rects.push_back({p.x, p.y, p.x + s.x, p.y + s.y});
}

// Switch control. Returns true when clicked.
bool toggleSwitch(const char* id, bool* v) {
    const float u = ImGui::GetFontSize() / 16.f;
    const ImVec2 p = ImGui::GetCursorScreenPos();
    const float w = 40 * u, h = 22 * u;
    ImGui::InvisibleButton(id, ImVec2(w, h));
    const bool clicked = ImGui::IsItemClicked();
    if (clicked) *v = !*v;

    ImDrawList* dl = ImGui::GetWindowDrawList();
    const ImU32 bg = *v ? ImGui::GetColorU32(accent) : IM_COL32(110, 110, 105, 255);
    dl->AddRectFilled(p, ImVec2(p.x + w, p.y + h), bg, h / 2);
    dl->AddCircleFilled(ImVec2(p.x + (*v ? w - 11 * u : 11 * u), p.y + h / 2), 8 * u, IM_COL32_WHITE);
    return clicked;
}

void drawSetting(Setting& s) {
    ImGui::PushID(s.name.c_str());
    ImGui::TextDisabled("%s", s.name.c_str());
    ImGui::SameLine(ImGui::GetFontSize() * 8);
    ImGui::SetNextItemWidth(-1);
    switch (s.type) {
        case Setting::Type::Slider:
            ImGui::SliderFloat("##v", &s.value, s.min, s.max, "%.0f");
            break;
        case Setting::Type::Toggle:
            ImGui::Checkbox("##v", &s.on);
            break;
        case Setting::Type::Choice: {
            const char* cur = s.choices[s.choice].c_str();
            if (ImGui::BeginCombo("##v", cur)) {
                for (int i = 0; i < (int)s.choices.size(); ++i)
                    if (ImGui::Selectable(s.choices[i].c_str(), i == s.choice)) s.choice = i;
                ImGui::EndCombo();
            }
            break;
        }
        case Setting::Type::Color:
            ImGui::ColorEdit4("##v", s.color, ImGuiColorEditFlags_NoInputs | ImGuiColorEditFlags_AlphaBar);
            break;
    }
    ImGui::PopID();
}

}  // namespace

const std::vector<input::Rect>& rects() { return g_rects; }

void draw(ImVec2 screen) {
    g_rects.clear();

    auto& mods = ModuleManager::get().modules();
    const float u = ImGui::GetFontSize() / 16.f;   // UI unit

    // Always-visible round button to open/close the menu.
    ImGui::SetNextWindowPos(ImVec2(screen.x * 0.5f, 6 * u), ImGuiCond_Always, ImVec2(0.5f, 0.f));
    ImGui::PushStyleColor(ImGuiCol_WindowBg, ImVec4(0, 0, 0, 0));
    ImGui::PushStyleColor(ImGuiCol_Border, ImVec4(0, 0, 0, 0));
    ImGui::PushStyleColor(ImGuiCol_Button, ImVec4(accent.x, accent.y, accent.z, 0.85f));
    ImGui::PushStyleVar(ImGuiStyleVar_FrameRounding, radius * u);
    if (ImGui::Begin("##mclient_toggle", nullptr,
                     ImGuiWindowFlags_NoDecoration | ImGuiWindowFlags_AlwaysAutoResize |
                     ImGuiWindowFlags_NoSavedSettings | ImGuiWindowFlags_NoMove |
                     ImGuiWindowFlags_NoFocusOnAppearing | ImGuiWindowFlags_NoNav)) {
        if (ImGui::Button(visible ? "  Close  " : "  Menu  ")) visible = !visible;
        addRect();
    }
    ImGui::End();
    ImGui::PopStyleVar();
    ImGui::PopStyleColor(3);

    if (!visible) return;

    const float w = std::min(screen.x - 24.f, 460.f * u);
    ImGui::SetNextWindowPos(ImVec2(screen.x * 0.5f, screen.y * 0.5f), ImGuiCond_FirstUseEver, ImVec2(0.5f, 0.5f));
    ImGui::SetNextWindowSize(ImVec2(w, screen.y * 0.8f), ImGuiCond_FirstUseEver);

    ImGui::PushStyleVar(ImGuiStyleVar_WindowRounding, (radius + 4) * u);
    ImGui::PushStyleVar(ImGuiStyleVar_FrameRounding, radius * u);
    ImGui::PushStyleColor(ImGuiCol_SliderGrab, accent);
    ImGui::PushStyleColor(ImGuiCol_CheckMark, accent);

    int on = 0;
    for (auto& m : mods) on += m->enabled;

    if (ImGui::Begin("My client", &visible, ImGuiWindowFlags_NoCollapse)) {
        addRect();
        ImGui::TextColored(accent, "My client");
        char count[32];
        std::snprintf(count, sizeof count, "%d of %d on", on, (int)mods.size());
        ImGui::SameLine(ImGui::GetWindowWidth() - ImGui::CalcTextSize(count).x - ImGui::GetStyle().WindowPadding.x);
        ImGui::TextDisabled("%s", count);

        ImGui::SetNextItemWidth(-1);
        ImGui::InputTextWithHint("##q", "Search modules", g_query, sizeof g_query);

        const char* names[] = {"All", "Movement", "HUD", "Render", "Utility"};
        for (int i = 0; i < 5; ++i) {
            const bool sel = (g_cat + 1 == i);
            if (sel) ImGui::PushStyleColor(ImGuiCol_Button, ImVec4(accent.x, accent.y, accent.z, 0.45f));
            if (ImGui::Button(names[i])) { g_cat = i - 1; g_open = -1; }
            if (sel) ImGui::PopStyleColor();
            if (i < 4) ImGui::SameLine();
        }
        ImGui::Separator();

        ImGui::BeginChild("list", ImVec2(0, 0), false);
        bool any = false;
        for (int i = 0; i < (int)mods.size(); ++i) {
            Module& m = *mods[i];
            if (g_cat >= 0 && (int)m.category != g_cat) continue;
            if (!containsNoCase(m.name, g_query)) continue;
            any = true;

            ImGui::PushID(i);
            ImGui::BeginGroup();

            const ImVec2 start = ImGui::GetCursorPos();
            ImGui::Text("%s", m.name.c_str());
            ImGui::TextDisabled("%s", m.description.c_str());
            const ImVec2 endPos = ImGui::GetCursorPos();

            // Tap (not drag) the title area to expand/collapse. A Dummy is used instead of a
            // button so that dragging from here can still scroll the list.
            ImGui::SetCursorPos(start);
            ImGui::Dummy(ImVec2(ImGui::GetContentRegionAvail().x - 52 * u, endPos.y - start.y));
            if (ImGui::IsItemHovered() && ImGui::IsMouseReleased(0) && !m.settings.empty()) {
                const ImGuiIO& io = ImGui::GetIO();
                const float dx = io.MousePos.x - io.MouseClickedPos[0].x;
                const float dy = io.MousePos.y - io.MouseClickedPos[0].y;
                if (dx * dx + dy * dy < (10 * u) * (10 * u)) g_open = (g_open == i) ? -1 : i;
            }

            ImGui::SetCursorPos(ImVec2(ImGui::GetWindowContentRegionMax().x - 44 * u, start.y + 4 * u));
            bool v = m.enabled;
            if (toggleSwitch("sw", &v)) m.setEnabled(v);
            ImGui::SetCursorPos(endPos);

            if (g_open == i) {
                ImGui::Separator();
                for (auto& s : m.settings) drawSetting(s);
            }

            ImGui::EndGroup();
            ImGui::Separator();
            ImGui::PopID();
        }
        if (!any) ImGui::TextDisabled("No modules match your search.");

        // Finger drag scrolls the list.
        if (ImGui::IsWindowHovered() && !ImGui::IsAnyItemActive() && ImGui::IsMouseDragging(0, 6.f))
            ImGui::SetScrollY(ImGui::GetScrollY() - ImGui::GetIO().MouseDelta.y);
        ImGui::EndChild();
    }
    ImGui::End();

    ImGui::PopStyleColor(2);
    ImGui::PopStyleVar(2);
}

}  // namespace ClickGUI
