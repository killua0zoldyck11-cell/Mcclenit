# mclient (levipack)

Native mod for LeviLaunchroid (Minecraft Bedrock, Android arm64) with a ClickGUI based on `clickgui_mockup.html`.
Packaged as a `.levipack` (zip with `manifest.json` + `libmclient.so`).

## What it does
- A **Menu** button at the top center of the screen opens the ClickGUI (search, categories, switches, settings).
- Modules: **FPS**, **Clock**, **CPS** (taps per second), **Custom crosshair**, **Themes**.
- Taps on the menu go to the menu; taps anywhere else go to the game.
- Settings are saved to `config/settings.json` inside the mod folder.

## How it works
- `eglSwapBuffers` is hooked with the SDK's `pl::memory::hook`; every frame ImGui is drawn on top of the game.
- Touch and keyboard come from `pl::input` callbacks and are passed to ImGui on the render thread (`src/input.cpp`).

## Build the .levipack
**Option A: GitHub (no setup).** Create a GitHub repo, upload this folder, open the *Actions* tab, run **build-levipack**, then download the artifact `mclient-levipack` (a zip containing `mclient.levipack`).

**Option B: locally.** Needs Android NDK r28c, CMake 3.22+, Ninja, git, zip.
```
export ANDROID_NDK_HOME=/path/to/ndk
./scripts/package.sh
```
Output: `dist/arm64-v8a/mclient.levipack`

## Install
LeviLaunchroid -> Import mod -> `mclient.levipack`.
Edit `minecraft_versions` in `manifest.json` to match your game version before building.

## Adding a module
1. Create `src/modules/yourmodule.h` deriving from `Module`.
2. Add settings in the constructor, draw in `onRender`.
3. Register it in `ModuleManager::registerAll()`.

## Status
The sources compile cleanly against the real SDK headers, and a headless test of the GUI, touch routing, CPS counting and settings save/load passes on a PC.
The `.so` itself has not been built or run on a phone yet.
